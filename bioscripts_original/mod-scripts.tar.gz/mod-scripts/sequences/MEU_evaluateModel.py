	# Python code written by ModelSoft using Modeller methods 
	# Software developed by Cassiana Chassot Fulber

from modeller import *
from modeller.scripts import complete_pdb

log.verbose()    # request verbose output
env = environ()
env.libs.topology.read(file='$(LIB)/top_heav.lib') # read topology
env.libs.parameters.read(file='$(LIB)/par.lib') # read parameters

for i in range(1, 101):
   # read model file

   code = "A0202.B9999%04d.pdb" % i
   mdl = complete_pdb(env, code)
   s = selection(mdl)
   s.assess_dope(output='ENERGY_PROFILE NO_REPORT', file='A0202_%d.profile' % i,
                 normalize_profile=True, smoothing_window=15)
