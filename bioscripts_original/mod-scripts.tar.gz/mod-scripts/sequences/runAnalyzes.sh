#$1 is ref or nonref models
#$2 is the target
#$3 is the log filename

case $1 in
'ref')
	./runProcheck100_refinados . $2

	./mainDope $2 . $3 true
	./mainRama $2 . true
	;;

'nonref')
	./runProcheck100_naoRefinados . $2

	./mainDope $2 . $3 false
	./mainRama $2 . false
	;;

esac
