/*
 * File:   main.cpp
 * Author: imuno
 *
 * Created on 22 de Dezembro de 2009, 14:42
 */

#include <stdlib.h>
#include<string>
#include<iostream>
#include<fstream>
#include<iomanip>
#include<sstream>
#include <bits/basic_string.h>
#include <algorithm>


using namespace std;

const int numberOfModels = 100;
const int numberOfParameters = 2;

string formatIndex(int val, int qtd){
    std::ostringstream temp;
    string saida;

    temp << val;
    saida = temp.str();
    int zeros = qtd - saida.length();

    if(zeros > 0)
       for(int i=0;i<zeros;i++)
           saida = "0"+saida;
    return saida;

}
string readDope(string line){
    int posBegin, posEnd, length;
    string dope;
        posBegin = line.find_first_of("1234567890-");
        posEnd = line.find_last_of("1234567890");
        length = posEnd - posBegin;
        dope = line.substr(posBegin, length);
        replace(dope.begin(), dope.end(), '.', ',');
    return dope;
}

void printDopes(string dopes[numberOfModels][numberOfParameters]){
    for (int model = 0; model <numberOfModels; model++)
    {
          for (int col = 0; col <2; col++)
          {
            cout << dopes[model][col] << "    ";
          }
          cout << endl;
    }
}


void swapLine(string dopes[numberOfModels][numberOfParameters], int smallerRowIndex, int biggerRowIndex){
    string colAux;
    for (int i = 0; i < 2; i++)
    {
        colAux = dopes[biggerRowIndex][i];
        dopes[biggerRowIndex][i] = dopes[smallerRowIndex][i];
        dopes[smallerRowIndex][i] = colAux;
    }
}


void sortDopes(string dopes[numberOfModels][numberOfParameters]){
  int bigest;
    for (int pass = 0; pass < numberOfModels; pass++){
        bigest = pass;
        for(int i = pass+1; i < numberOfModels; i++){
            if (dopes[i][1] > dopes[bigest][1])
                bigest = i;
        }
        swapLine(dopes, pass, bigest);

}
}

void dopesToCSV(string dopes[numberOfModels][numberOfParameters], string target, string path){
    ofstream sortFile;
    string pathSort, outputLine;

    pathSort = path + "/" + target + "_DOPESort.csv";
    sortFile.open(pathSort.c_str());
    if (sortFile.is_open()){
        for (int row = 0; row < numberOfModels; row++)
        {
            outputLine = dopes[row][0];
            for(int col = 1; col < 2; col++)
            {
                outputLine = outputLine + ";" + dopes[row][col];
            }
            sortFile << outputLine << endl;
        }

}
}


int main(int argc, char *argv[]) {
    fstream dopeFile;
    string target, path, modelIndexPath, modelCode;
    string firstDopeLine, line, filename, partial_path;
  
	int modelIndex;

    string DOPE[numberOfModels][numberOfParameters];
	string refModels;
int max;

    target = argv[1];
partial_path = argv[2];
filename = argv[3];
refModels = argv[4];


 
    cout << "Realizando leitura de dados de DOPE..." << endl << endl;
	path = partial_path + "/" +  filename;

    dopeFile.open(path.c_str());

	if (refModels == "true")
	{ max = 235;}
	if (refModels == "false")
	{ max = 231;}



    if (dopeFile.is_open())
    {
        for (int lineIndex = 0; lineIndex < max; lineIndex++)
        {
            getline(dopeFile, firstDopeLine);
         }
	     

         DOPE[0][0] = target + "." + "0001";
        
         DOPE[0][1] = readDope(firstDopeLine);

         for (int modelIndex = 1; modelIndex < numberOfModels; modelIndex++)
         {
             modelCode = target + "." + formatIndex(modelIndex+1, 4);
            for (int lineIndex = 0; lineIndex < 158; lineIndex++)
            {
                getline(dopeFile, line);
            }
           // cout << "modelo " << modelIndex << ": " << line << endl;
            DOPE[modelIndex][1] = readDope(line);
            DOPE[modelIndex][0] = modelCode;
         }

      }
    else
    cout << "Unable to open file. Please try again.";

    //printDopes(DOPE, numberOfModels);
   // cout << endl;
    sortDopes(DOPE);
    //printDopes(DOPE, numberOfModels);
    //cout << endl;
    dopesToCSV(DOPE, target, partial_path);

    return (EXIT_SUCCESS);
}
