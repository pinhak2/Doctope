#include <stdlib.h>
#include<string>
#include<iostream>
#include<fstream>
#include<iomanip>
#include<sstream>
#include <bits/basic_string.h>
#include <algorithm>


using namespace std;

const int MAX_MODELS = 100;

int getRamaValue(string line) {
    int posBegin, posEnd, length;
    string rama;
	string newline;
	int ramaValue;

        posBegin = line.find_first_of(".");
	posBegin = posBegin + 6; // passa os quatro digitos de indice do modelo, mais o ;
	newline = line.substr(posBegin);
        posEnd = newline.find_first_of(";") + posBegin;
        length = posEnd - posBegin;
        rama = line.substr(posBegin, length);

	rama.erase(2,1);
	if (rama.length() == 2) {
		rama.push_back('0');
	} 
	
	cout << "RAMA: " << rama << endl;
	ramaValue = atoi(rama.c_str()); 
    
	return ramaValue;
}

int getDopeValue(string line) {
    int posBegin, posEnd, length;
    string dope;
	int dopeValue;
        posBegin = line.find_first_of("-");
        posEnd = line.find_last_of("1234567890");
        length = posEnd - posBegin;
        dope = line.substr(posBegin, length);
        replace(dope.begin(), dope.end(), '.', ',');
	
	
	dope.erase(6,1);
	dopeValue = atoi(dope.c_str()); 
    return dopeValue;
}

int getModelIndex(string line) {
	int posBegin, posEnd, length;
	string modelIndex;
	int index;

	posBegin = line.find_first_of(".") +1;
	posEnd = line.find_first_of(";");
	length = posEnd - posBegin;
    modelIndex = line.substr(posBegin, length);

	index = atoi(modelIndex.c_str());
	return index;
}

int main(int argc, char *argv[]) {
	fstream ramafile, dopefile;
	string pathDope, pathRama;
	string line, dopeline, ramaline;
	int bestDope, bestRama, eqRamaDope;
	int ramaValue, dopeValue;
	int maxRamaDope, sum;
	int modelIndex;

	string dopeArray[MAX_MODELS];
	string ramaArray[MAX_MODELS];

	pathDope = argv[1];
	pathRama = argv[2];

	maxRamaDope = 0;
	sum = 0;
	modelIndex = 1;


	dopefile.open(pathDope.c_str());
	ramafile.open(pathRama.c_str());

	if(dopefile.is_open()) {

		for (int lineIndex = 1; lineIndex <= MAX_MODELS; lineIndex++) {
			getline(dopefile, line);

			if (lineIndex==1) {
				bestDope = getModelIndex(line);
			}

			modelIndex = getModelIndex(line);
			dopeArray[modelIndex-1] = line;
		}	

	}	


	if(ramafile.is_open()) {
		for (int lineIndex = 1; lineIndex <= MAX_MODELS; lineIndex++) {
			getline(ramafile, line);

			if (lineIndex==1) {
				bestRama = getModelIndex(line);
			}

			modelIndex = getModelIndex(line);
			ramaArray[modelIndex-1] = line; 
		}
	}	
	

	dopefile.close();
	ramafile.close();

	for (int lineIndex = 0; lineIndex < MAX_MODELS; lineIndex++) {
		cout << ramaArray[lineIndex] << " === " << dopeArray[lineIndex] << endl;
}

	for (int lineIndex = 0; lineIndex < MAX_MODELS; lineIndex++) {
		ramaValue = getRamaValue(ramaArray[lineIndex]);
		dopeValue = getDopeValue(dopeArray[lineIndex]);

		sum = ramaValue - dopeValue;

		cout << lineIndex << ": " << ramaValue << " - " << dopeValue << " - " << sum << endl;
		if (sum >= maxRamaDope) {
			maxRamaDope = sum;
			eqRamaDope = lineIndex+1;
		}
	}

	cout << "Best DOPE model: " << bestDope << endl;
	cout << "Best Ramachandra model: " << bestRama << endl;
	cout << "Equilibrium model: " << eqRamaDope << endl;	

	return 0;
}
