/*
 * File:   main.cpp
 * Author: imuno
 *
 * Created on 18 de Dezembro de 2009, 16:12
 */

#include <stdlib.h>
#include<string>
#include<iostream>
#include<fstream>
#include<iomanip>
#include<sstream>

using namespace std;

const int numberOfModels = 100;
const int numberOfParameters = 5;

string formatIndex(int val, int qtd){
    std::ostringstream temp;
    string saida;

    temp << val;
    saida = temp.str();
    int zeros = qtd - saida.length();

    if(zeros > 0)
    {
       for(int i=0;i<zeros;i++)
       {
          saida = "0"+saida;
       }
    }
    return saida;

}

void swapLine(string matrix[numberOfModels][numberOfParameters], int smallerRowIndex, int biggerRowIndex){
    string colAux;
    for (int i = 0; i < numberOfParameters; i++)
    {
        colAux = matrix[biggerRowIndex][i];
        matrix[biggerRowIndex][i] = matrix[smallerRowIndex][i];
        matrix[smallerRowIndex][i] = colAux;
    }
}

void printMatrix(string matrix[numberOfModels][numberOfParameters], int rows, int cols){
     for (int row=0; row<rows;row++)
        {
            for(int col=0; col<cols;col++)
                cout << matrix[row][col] << "    ";
                cout << endl;
        }
}

void sortCol(string matrix[numberOfModels][numberOfParameters], int rows, int col){
    int bigest;
    for (int pass = 0; pass < rows; pass++){
        bigest = pass;
        for(int i = pass+1; i < rows; i++){
            if (matrix[i][col] > matrix[bigest][col])
                bigest = i;
        }
        swapLine(matrix, pass, bigest);
    }
}

void sortMatrix(string matrix[numberOfModels][numberOfParameters]){
    for (int col = numberOfParameters-1; col > 0; col--)
    {
        sortCol(matrix, numberOfModels, col);
    }
}

string percentagesMatrix(string &line){
    int posBegin, posEnd, length;
    string percentage;

int	posAlgarism = line.find_first_of("1234567890");
int	posDot = line.find_first_of(".");
    posBegin = posAlgarism;

	if (posDot < posAlgarism) {
		posBegin = posDot;
		int posInsert = posDot--;
		line.insert(posInsert, "0");

//string& insert( size_type index, const string& str );
	
	} 


    posEnd = line.find_first_of("%", posBegin);
    length = posEnd - posBegin;
    percentage = line.substr(posBegin, length);

	posBegin = percentage.find_first_of(".");

	percentage.replace(posBegin, 1, ",");

    line = line.substr(posEnd);


    return percentage;
}

void matrixToCSV(string target, string matrix[numberOfModels][numberOfParameters], string path){
    ofstream sortFile;
    string pathSort, outputLine;

    pathSort = path + "/" + target + "_RamaSort.csv";
    sortFile.open(pathSort.c_str());
    if (sortFile.is_open()){
        for (int row = 0; row < numberOfModels; row++)
        {
            outputLine = matrix[row][0];
            for(int col = 1; col < numberOfParameters; col++)
            {
                outputLine = outputLine + ";" + matrix[row][col];
            }
            sortFile << outputLine << endl;
        }


    }
}

int main(int argc, char *argv[]) {
    fstream ramafile;
    string target, modelIndexPath, pathRama;
    string modelCode;
    string line;
	string path;
    int modelIndex, parameterIndex;
	string refModels;

    string matrix[numberOfModels][numberOfParameters];

    target = argv[1];
	path = argv[2];
	refModels = argv[3];

    // CALCULA INDICE PARA NOME DO ARQUIVO
    cout << "Realizando leitura de dados do Ramachandran..." << endl << endl;
    for( modelIndex=0;modelIndex<numberOfModels;modelIndex++)
    {
        modelIndexPath = formatIndex(modelIndex+1, 4);
        modelCode = target + "." + modelIndexPath;

	if (refModels == "true")
	{
		pathRama = path + "/" + target + ".BL" + modelIndexPath + "0001.sum";			
	}
	if (refModels == "false")
	{
		pathRama = path + "/" + target + ".B9999" + modelIndexPath + ".sum";
	}


        ramafile.open(pathRama.c_str());

        if (ramafile.is_open())
        {
            for (int lineIndex = 1; lineIndex < 7; lineIndex++)
            {
                getline(ramafile, line);
                
            }

            // PROCURA OS QUATRO VALORES E GRAVA EM UMA MATRIZ
            matrix[modelIndex][0] = modelCode;
            for (int parameterIndex=1; parameterIndex<numberOfParameters; parameterIndex++)
            {
                matrix[modelIndex][parameterIndex] = percentagesMatrix(line);
            }
            ramafile.close();

        }
        else
            cout << "Unable to open file. Please try again." << endl;
    }

     //printMatrix(matrix, numberOfModels, numberOfParameters);
     sortMatrix(matrix);
    // printMatrix(matrix, numberOfModels, numberOfParameters);
     matrixToCSV(target, matrix, path);

     return (EXIT_SUCCESS);
}

