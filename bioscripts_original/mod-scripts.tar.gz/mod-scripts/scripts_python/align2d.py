# -*- coding: utf-8 -*-
# File: align2d.py
# Reading the seg files and passing the sequences to a ali file.

from modeller import *

log.verbose()
env = environ()

#Considering heteroatoms and waters molecules
env.io.hetatm = env.io.water = True
# Directories with input atom files:
env.io.atom_files_directory = './:../atom_files'

# Identity matrix filename:
env.matrix_file = 'fer2.id.mat'
# Write out the superposed structures:
env.write_fit = True
# Some alignment parameters:
env.overhang = 4


#Reading file.seg
aln = alignment(env)
aln.append(file='./sequences/1OHR.seg ',
           align_codes='./sequences/1OHR',),
aln.append(file='./sequences/RS101POL.seg ',
           align_codes='./sequences/RS101POL')

# Aligning seg files and writing file.ali and file.pap
aln.align2d()
aln.write(file='./sequences/1OHR_RS101POL.ali',
          alignment_format='PIR')
aln.write(file='./sequences/1OHR_RS101POL.pap',
          alignment_format='PAP')
